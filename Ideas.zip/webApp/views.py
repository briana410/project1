from flask import Blueprint, render_template
from flask_bootstrap import Bootstrap

views = Blueprint('veiws', __name__)

@views.route('/')

def home():
    print('Request for home page received')
    return render_template('login.html')
