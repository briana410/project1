from flask import Blueprint, render_template, request, redirect, url_for, send_from_directory

auth = Blueprint('auth', __name__)

@auth.route('/login')

def login():
   print('Request for index page received')
   return render_template('home.html')

@auth.route('/logout')

def logout():
    return "<h1>Loging out</h1>"
